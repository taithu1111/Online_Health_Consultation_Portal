﻿namespace Online_Health_Consultation_Portal.Domain.Enum
{
    public enum AppointmentStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Diagnosed,   // <== thêm
        Completed
    }
}
