﻿using System.Net.Mail;
using System.Net;

namespace Online_Health_Consultation_Portal.Infrastructure.Service
{
    public class EmailService : IEmailService
    {
        private readonly string _smtpServer;
        private readonly int _smtpPort;
        private readonly string _smtpUsername;
        private readonly string _smtpPassword;

        public EmailService(IConfiguration configuration)
        {
            //_smtpServer = configuration["EmailSettings:SmtpServer"]!;
            //_smtpPort = int.Parse(configuration["EmailSettings:SmtpPort"]!);
            //_smtpUsername = configuration["EmailSettings:SmtpUsername"]!;
            //_smtpPassword = configuration["EmailSettings:SmtpPassword"]!;


            _smtpServer = configuration["EmailSettings:Host"]!;
            _smtpPort = int.Parse(configuration["EmailSettings:Port"]!);
            _smtpUsername = configuration["EmailSettings:Email"]!;
            _smtpPassword = configuration["EmailSettings:Password"]!;
        }

        public async Task SendEmailAsync(string email, string subject, string message)
        {
            using (var client = new SmtpClient(_smtpServer, _smtpPort))
            {
                client.Credentials = new NetworkCredential(_smtpUsername, _smtpPassword);
                client.EnableSsl = true;

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_smtpUsername),
                    Subject = subject,
                    Body = message,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(email);

                await client.SendMailAsync(mailMessage);
            }
        }
    }
}
