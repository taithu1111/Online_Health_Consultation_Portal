﻿using MediatR;
using Online_Health_Consultation_Portal.Application.Dtos.ConsultationSession;

namespace Online_Health_Consultation_Portal.Application.Queries.ConsultationSession
{
    public class GetConsultationsByDoctorQuery : IRequest<List<ConsultationSessionDto>>
    {
        public int DoctorId { get; set; }
    }
}
