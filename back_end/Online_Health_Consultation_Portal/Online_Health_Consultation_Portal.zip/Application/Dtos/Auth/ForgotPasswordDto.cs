﻿namespace Online_Health_Consultation_Portal.Application.Dtos.Auth
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
