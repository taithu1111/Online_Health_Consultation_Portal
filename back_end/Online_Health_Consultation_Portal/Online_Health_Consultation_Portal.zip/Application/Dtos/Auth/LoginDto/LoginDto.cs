﻿namespace Online_Health_Consultation_Portal.Application.Dtos.Auth.LoginDto
{
    public class LoginDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
