﻿namespace Online_Health_Consultation_Portal.Application.Dtos.Schedule
{
    public class AvailableSlotDto
    {
        public DateTime SlotStart { get; set; }
        public DateTime SlotEnd { get; set; }
    }
}
