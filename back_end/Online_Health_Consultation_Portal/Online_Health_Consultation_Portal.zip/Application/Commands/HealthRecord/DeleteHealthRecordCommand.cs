﻿using MediatR;

namespace Online_Health_Consultation_Portal.Application.Commands.HealthRecord
{
    public class DeleteHealthRecordCommand : IRequest<bool>
    {
        public int Id { get; set; }
        public DeleteHealthRecordCommand(int id)
        {
            Id = id;
        }
    }
}
